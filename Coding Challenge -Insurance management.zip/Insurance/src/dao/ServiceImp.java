package dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import exception.PolicyNotFoundException;
import util.DBConnUtil;
import entity.Policy;

public class ServiceImp implements IPolicyService {

    private Connection conn;

    public ServiceImp() {
        try {
            this.conn = DBConnUtil.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean createPolicy(Policy policy) {
        String sql = "INSERT INTO Policy (policyId, policyName, coverageAmount, policyType) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, policy.getPolicyId());
            stmt.setString(2, policy.getPolicyName());
            stmt.setDouble(3, policy.getCoverageAmount());
            stmt.setString(4, policy.getPolicyType());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Policy getPolicy(int policyId) throws PolicyNotFoundException {
        String sql = "SELECT * FROM Policy WHERE policyId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, policyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),         // Correct position
                    rs.getDouble("coverageAmount")      // Correct position
                );
            } else {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public List<Policy> getAllPolicies() {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM Policy";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Policy p = new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),        // fixed position
                    rs.getDouble("coverageAmount")     // fixed position
                );
                policies.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
    }


    @Override
    public boolean updatePolicy(Policy policy) {
        String sql = "UPDATE Policy SET policyName = ?, coverageAmount = ?, policyType = ? WHERE policyId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, policy.getPolicyName());
            stmt.setDouble(2, policy.getCoverageAmount());
            stmt.setString(3, policy.getPolicyType());
            stmt.setInt(4, policy.getPolicyId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deletePolicy(int policyId) {
        String sql = "DELETE FROM Policy WHERE policyId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, policyId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}