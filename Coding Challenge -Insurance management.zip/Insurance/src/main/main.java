package main;

import java.util.List;
import java.util.Scanner;

import dao.ServiceImp;
import entity.Policy;
import exception.PolicyNotFoundException;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ServiceImp service = new ServiceImp();

        while (true) {
            System.out.println("\n--- Insurance Management System ---");
            System.out.println("1. Create Policy");
            System.out.println("2. Get Policy by ID");
            System.out.println("3. Get All Policies");
            System.out.println("4. Update Policy");
            System.out.println("5. Delete Policy");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Policy ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Policy Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Policy Type: ");
                    String type = sc.nextLine();
                    System.out.print("Enter Coverage Amount: ");
                    double amount = sc.nextDouble();
                    Policy newPolicy = new Policy(id, name, type, amount);
                    boolean created = service.createPolicy(newPolicy);
                    System.out.println(created ? "Policy created successfully!" : "Failed to create policy.");
                    break;

                case 2:
                    System.out.print("Enter Policy ID to fetch: ");
                    int fetchId = sc.nextInt();
                    try {
                        Policy fetched = service.getPolicy(fetchId);
                        System.out.println("Policy Details:");
                        System.out.println("ID: " + fetched.getPolicyId());
                        System.out.println("Name: " + fetched.getPolicyName());
                        System.out.println("Type: " + fetched.getPolicyType());
                        System.out.println("Coverage: " + fetched.getCoverageAmount());
                    } catch (PolicyNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    List<Policy> policies = service.getAllPolicies();
                    if (policies.isEmpty()) {
                        System.out.println("No policies found.");
                    } else {
                        System.out.println("All Policies:");
                        for (Policy p : policies) {
                            System.out.println("ID: " + p.getPolicyId() + ", Name: " + p.getPolicyName() + ", Type: " + p.getPolicyType() + ", Coverage: " + p.getCoverageAmount());
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Policy ID to update: ");
                    int updId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Policy Name: ");
                    String updName = sc.nextLine();
                    System.out.print("Enter New Policy Type: ");
                    String updType = sc.nextLine();
                    System.out.print("Enter New Coverage Amount: ");
                    double updAmount = sc.nextDouble();
                    Policy updatedPolicy = new Policy(updId, updName, updType, updAmount);
                    boolean updated = service.updatePolicy(updatedPolicy);
                    System.out.println(updated ? "Policy updated successfully!" : "Failed to update policy.");
                    break;

                case 5:
                    System.out.print("Enter Policy ID to delete: ");
                    int delId = sc.nextInt();
                    boolean deleted = service.deletePolicy(delId);
                    System.out.println(deleted ? "Policy deleted successfully!" : "Policy not found or couldn't be deleted.");
                    break;

                case 6:
                    System.out.println("Exiting system.");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
