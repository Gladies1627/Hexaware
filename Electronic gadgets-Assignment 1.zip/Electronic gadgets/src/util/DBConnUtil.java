package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/techshop";
    private static final String USER = "root";
    private static final String PASSWORD = "gladies@1627!";
    private static Connection con;

    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("\u2705 Connection Established");
            }
        } catch (Exception e) {
            System.out.println("\u274C Connection Failed: " + e.getMessage());
        }
        return con;
    }


}