package entity;

import java.time.LocalDateTime;

public class Inventory {
    private int inventoryID;
    private Products product;
    private int quantityInStock;
    private LocalDateTime lastStockUpdate;

    // Constructor to initialize the Inventory object
    public Inventory(int inventoryID, Products product, int quantityInStock, LocalDateTime lastStockUpdate) {
        this.inventoryID = inventoryID;
        this.product = product;
        setQuantityInStock(quantityInStock); // Use the setter to validate quantity
        this.lastStockUpdate = lastStockUpdate;
    }

    // Getter for inventoryID
    public int getInventoryID() {
        return inventoryID;
    }

    // Getter for product
    public Products getProduct() {
        return product;
    }

    // Setter for product to allow modification
    public void setProduct(Products product) {
        this.product = product;
    }

    // Getter for quantityInStock
    public int getQuantityInStock() {
        return quantityInStock;
    }

    // Setter for quantityInStock with validation
    public void setQuantityInStock(int quantityInStock) {
        if (quantityInStock < 0) {
            throw new IllegalArgumentException("Quantity in stock must be non-negative.");
        }
        this.quantityInStock = quantityInStock;
    }

    // Getter for lastStockUpdate
    public LocalDateTime getLastStockUpdate() {
        return lastStockUpdate;
    }

    // Setter for lastStockUpdate
    public void setLastStockUpdate(LocalDateTime lastStockUpdate) {
        this.lastStockUpdate = lastStockUpdate;
    }

    // Additional helper method to get product ID (if needed directly)
    public int getProductID() {
        if (this.product != null) {
            return this.product.getProductID(); // Access the product ID of the associated Product
        }
        return -1; // Return -1 if product is null (indicating missing product)
    }
}
