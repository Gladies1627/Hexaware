package entity;

public class Products {
    private int productID;
    private String productName;
    private String description;
    private double price;
    private String category;

    public Products(int productID, String productName, String description, double price, String category) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.category = category;
    }

    // Getters and setters (if needed)
    public int getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return String.format(
            "ID: %d | Name: %s | Description: %s | Price: ₹%.2f | Category: %s",
            productID, productName, description, price, category
        );
    }
}
