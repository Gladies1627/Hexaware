package dao;

import entity.Employee;
import entity.Project;
import entity.Task;

public interface IProjectRepository {
    boolean addEmployee(Employee emp);
    boolean addProject(Project project);
    boolean addTask(Task task);
    boolean assignProjectToEmployee(int empId, int projectId);
    boolean assignTaskToEmployee(int empId, int taskId);
}
