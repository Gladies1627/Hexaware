package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Employee;
import entity.Project;
import entity.Task;
import util.DBConnUtil;

public class ProjectRepositoryImpl implements IProjectRepository {

    private Connection conn;

    public ProjectRepositoryImpl() {
        conn = DBConnUtil.getConnection();
    }

    @Override
    public boolean addProject(Project project) {
        if (conn == null) {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Project (id, projectName, description, startDate, status) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, project.getId());
            pstmt.setString(2, project.getProjectName());
            pstmt.setString(3, project.getDescription());
            pstmt.setDate(4, project.getStartDate());
            pstmt.setString(5, project.getStatus());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in addProject(): " + e.getMessage());
            return false;
        }
    }

    public boolean addEmployee(Employee emp) {
        if (conn == null) {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, emp.getId());
            pstmt.setString(2, emp.getName());
            pstmt.setString(3, emp.getDesignation());
            pstmt.setString(4, emp.getGender());
            pstmt.setDouble(5, emp.getSalary());
            pstmt.setInt(6, emp.getProjectId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in addEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean addTask(Task task) {
        if (conn == null) {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, task.getTaskId());
            pstmt.setString(2, task.getTaskName());
            pstmt.setInt(3, task.getProjectId());
            pstmt.setInt(4, task.getEmployeeId());
            pstmt.setString(5, task.getStatus());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in addTask(): " + e.getMessage());
            return false;
        }
    }

    public boolean assignProjectToEmployee(int empId, int projectId) {
        if (conn == null) {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "UPDATE Employee SET project_id = ? WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, empId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in assignProjectToEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean assignTaskToEmployee(int empId, int taskId) {
        if (conn == null) {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "UPDATE Task SET employee_id = ? WHERE task_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, empId);
            pstmt.setInt(2, taskId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in assignTaskToEmployee(): " + e.getMessage());
            return false;
        }
    }
}
