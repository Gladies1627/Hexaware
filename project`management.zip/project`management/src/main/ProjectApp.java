package main;

import dao.ProjectRepositoryImpl;
import entity.Employee;
import entity.Project;
import entity.Task;

import java.sql.Date;
import java.util.Scanner;

public class ProjectApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ProjectRepositoryImpl repo = new ProjectRepositoryImpl();

        while (true) {
            System.out.println("\nProject Management System");
            System.out.println("1. Add Project");
            System.out.println("2. Add Employee");
            System.out.println("3. Add Task");
            System.out.println("4. Assign Project to Employee");
            System.out.println("5. Assign Task to Employee");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
            case 1: {
            	System.out.print("Enter Project ID: ");
                int id = sc.nextInt();
                sc.nextLine(); // consume newline

                System.out.print("Enter Project Name: ");
                String projectName = sc.nextLine();

                System.out.print("Enter Description: ");
                String description = sc.nextLine();

                System.out.print("Enter Start Date (yyyy-mm-dd): ");
                String startDateStr = sc.nextLine();
                Date startDate = Date.valueOf(startDateStr); // java.sql.Date

                System.out.print("Enter Status: ");
                String status = sc.nextLine();

                Project project = new Project(id, projectName, description, startDate, status);
                boolean added = repo.addProject(project);
                System.out.println(added ? "Project added!" : "Failed to add project");
                break;
                
            }

            case 2: {
            	System.out.print("Enter Employee ID: ");
                int id = sc.nextInt();
                sc.nextLine(); // consume newline

                System.out.print("Enter Employee Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Designation: ");
                String designation = sc.nextLine();

                System.out.print("Enter Gender: ");
                String gender = sc.nextLine();

                System.out.print("Enter Salary: ");
                double salary = sc.nextDouble();

                System.out.print("Enter Project ID: ");
                int projectId = sc.nextInt();

                Employee emp = new Employee(id, name, designation, gender, salary, projectId);
                boolean added = repo.addEmployee(emp);
                System.out.println(added ? "Employee added!" : "Failed to add employee");
                break;
            }


            case 3: {
                System.out.print("Enter Task ID: ");
                int taskId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter Task Name: ");
                String taskName = sc.nextLine();

                System.out.print("Enter Project ID: ");
                int projectId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter Employee ID (or 0 if not assigned yet): ");
                int employeeId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter Status: ");
                String status = sc.nextLine();

                Task task = new Task(taskId, taskName, status, projectId, employeeId);
                boolean added = repo.addTask(task);
                System.out.println(added ? "Task added!" : "Failed to add task");
                break;
            }


                case 4: {
                    System.out.print("Enter Employee ID: ");
                    int empId = sc.nextInt();
                    System.out.print("Enter Project ID to assign: ");
                    int projId = sc.nextInt();

                    boolean assigned = repo.assignProjectToEmployee(empId, projId);
                    System.out.println(assigned ? "Project assigned to employee!" : "Failed to assign project");
                    break;
                }

                case 5: {
                    System.out.print("Enter Employee ID: ");
                    int empId = sc.nextInt();
                    System.out.print("Enter Task ID to assign: ");
                    int taskId = sc.nextInt();

                    boolean assigned = repo.assignTaskToEmployee(empId, taskId);
                    System.out.println(assigned ? "Task assigned to employee!" : "Failed to assign task.");
                    break;
                }

                case 6: {
                    System.out.println("Exiting...!");
                    System.exit(0);
                }

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
